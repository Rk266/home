$(document).ready(function () {
    // set column+content
    updateColumnsAndContent();

    // responsive header
    responsiveheader();

    // responsive footer
    footerExplanCollapse();

    clickEventsInCategoryPage();

    set_cart_scroll();

    $(window).resize(function () {
        // set column+content
        updateColumnsAndContent();
    });

    // $( ".block_box .owl-carousel:has(.owl-nav.disabled)" ).addClass( "nav_none" );
});

$(window).resize(function () {
    responsiveheader();
});



/*----------
Update column & content in responsive
-----------*/
function updateColumnsAndContent() {
    if ($(window).width() < 992) {
        $('#column-left, #column-right').insertAfter('#content');

        // menu
        if ($("#menu .dropdown.menulist .toggle-menu").length == 0) {
            $("#menu .dropdown.menulist").append("<span class='toggle-menu'><i class='fa fa-plus'></i></span>");
            $("#menu .dropdown.menulist .dropdown-submenu.sub-menu-item").append("<span class='toggle-menu'><i class='fa fa-plus'></i></span>");
            $('#topCategoryList ul.sub-menu').removeAttr("style");
            $('#topCategoryList div.dropdown-menu').removeAttr("style");
            $('#topCategoryList').hide();
            // call explan-collapse
            // responsiveMenuExpandCollapse();
        }

        // left, right
        $("#column-left .box-category .toggle-open, #column-right .box-category .toggle-open, #column-left .box-content .toggle-open, #column-right .box-content .toggle-open").remove();
        $("#column-left .box-category h3, #column-right .box-category h3, #column-left .box-content h3, #column-right .box-content h3").append("<span class='toggle-open'><i class='fa fa-chevron-down'></i></span>");
        $('#column-left ul.parent, #column-right ul.parent, #column-left .block_box, #column-right .block_box, #column-left .box-content ul, #column-right .box-content ul, #column-left .filter_box, #column-right .filter_box').hide();

    } else {

        $('#column-right').insertAfter('#content');
        $('#column-left').insertBefore('#content');

        // menu
        $("#menu .dropdown.menulist .toggle-menu").remove();
        $('#topCategoryList').show();
        $('#topCategoryList ul.sub-menu').removeAttr("style");
        $('#topCategoryList div.dropdown-menu').css("display", "");


        // left, right
    $("#column-left .box-category .toggle-open, #column-left .box-content .toggle-open").remove();
    $("#column-right .box-category .toggle-open, #column-right .box-content .toggle-open").remove();
    $('#column-left ul.parent, #column-right ul.parent, #column-left .block_box, #column-right .block_box, #column-left .box-content ul, #column-right .box-content ul, #column-left .filter_box, #column-right .filter_box').show();

    }
}

function responsiveheader() {
    var this_window_width = $(window).width();
    if (this_window_width <= 991) {
        $('.header-center').insertBefore('.search-content');
    }
    else if (this_window_width <= 1199 && this_window_width >= 992) {
        $('.header-center').insertAfter('.header-inner');
    }
    else {
        $('.header-center').insertBefore('.header-right');
    }
}

// MegaMenu 
$(document).ready(function () {

    /* headerfixed */
    var headerfixed = 1;
    if (headerfixed == 1) {
        $(window).scroll(function () {
            if ($(this).scrollTop() > 160) {
                $('header').addClass('header-fixed');
            } else {
                $('header').removeClass('header-fixed');
            }
        });
    }
    else {
        $('header').removeClass('header-fixed');
    }

    /* .headerfixed */
});

jQuery(window).resize(function () {
    responsiveheader();
    updateColumnsAndContent();
});

function set_cart_scroll() {
    var header_height = $("header").height();
    var screen_height = $(window).height();
    var cart_list_height = $("#cart .dropdown-menu .table-striped").height();
    var cart_total_height = $("#cart .dropdown-menu li+li").height();
    var cart_div_height = parseInt(cart_list_height) + parseInt(cart_total_height) + 10;
    var cart_div_max_height = parseInt(screen_height) - parseInt(header_height);
    var cart_total_pro = jQuery('.cart-content-product table  tr').length;
    if (screen_height < cart_div_height) {
        $("#cart .dropdown-menu").css({ "overflow-y": "unset", "max-height": "unset" });
        $("ul.dropdown-menu.pull-right").addClass("scroll_cart_dropdown").css({ "overflow-y": "auto", "max-height": cart_div_max_height + "px" });
    } else {
        $("ul.dropdown-menu.pull-right").removeClass("scroll_cart_dropdown").css({ "overflow-y": "unset", "max-height": "unset" });
        $("#cart .dropdown-menu ul").css({ "overflow-y": "auto", "max-height": "240px" });
    }
}


$(function () {
    $("#form-currency .dropdown-toggle").on('click', function () {
        $(".currency-dropdown").slideToggle("2000");
        $(".header-cart-toggle, .language-dropdown, .account-link-toggle").slideUp("slow");
        return false;
    });

    $("#cart button.dropdown-toggle").on('click', function () {
        $(".header-cart-toggle").slideToggle("2000");
        $(".account-link-toggle, .currency-dropdown, .language-dropdown").slideUp("slow");
        setTimeout(function () { set_cart_scroll(); }, 500);
        return false;
    });

    $("#header_ac a.dropdown-toggle").on('click', function () {
        $(".account-link-toggle").slideToggle("2000");
        $(".header-cart-toggle, .currency-dropdown, .language-dropdown").slideUp("slow");
        return false;
    });

    $(".search-content .search-btn-outer").on('click', function () {
        $(this).toggleClass('active');
        $(".header-search").slideToggle("2000");
        $(".account-link-toggle, .currency-dropdown, .header-cart-toggle, .language-dropdown").hide();
        return false;
    });

    // Hide Search Dropdown On Scroll 
    $(window).scroll(function () {
        $('.ui-autocomplete.ui-widget-content').hide();
    });

});


// ToggleClass in footer and about and shop page
function footerExplanCollapse() {

    $(".footer-row h4").addClass('toggled');
    $('.footer-row .toggled').on('click', function (e) {
        e.preventDefault();
        if ($(window).width() < 992) {
            $(this).toggleClass('active');
            $(this).parent().find('ul').toggleClass('active').toggle('slow');
        }
    });
}


/*----------
   Category page click events
   ----------*/
function clickEventsInCategoryPage() {
    $('.box-category .toggled').on('click', function (e) {
        e.preventDefault();
        if ($(window).width() < 992) {
            $(this).toggleClass('active');
            $(this).parent().find('ul.parent').toggleClass('active').slideToggle('slow');
        }
    });
    $('#column-left .box-content .toggled').on('click', function (e) {
        e.preventDefault();
        if ($(window).width() < 992) {
            $(this).toggleClass('active');
            if ($(this).parent().find('ul').length != 0) {
                $(this).parent().find('ul').toggleClass('active').slideToggle('slow');
            } else {
                $(this).parent().find('.filter_box').toggleClass('active').slideToggle('slow');
                $(this).parent().find('.block_box').toggleClass('active').slideToggle('slow');
            }
        }
    });
    $('#column-right .box-content .toggled').on('click', function (e) {
        e.preventDefault();
        if ($(window).width() < 992) {
            $(this).toggleClass('active');
            if ($(this).parent().find('ul').length != 0) {
                $(this).parent().find('ul').toggleClass('active').slideToggle('slow');
            } else {
                $(this).parent().find('.filter_box').toggleClass('active').slideToggle('slow');
                $(this).parent().find('.block_box').toggleClass('active').slideToggle('slow');
            }
        }
    });
}

