$('.banner-slider').owlCarousel({
    loop: true,
    nav: true,
    navText: ['<i class="fa fa-angle-left"></i>', '<i class="fa fa-angle-right"></i>'],
    dots: false,
    margin: 0,
    responsive: {
        0: {
            items: 1
        }
    }
});

$('.main-box').owlCarousel({
    loop: false,
    margin: 30,
    nav: true,
    navText: ['<i class="fa fa-angle-left"></i>', '<i class="fa fa-angle-right"></i>'],
    dots: false,
    responsiveClass: true,
    responsive: {
        0: {
            items: 1
        },
        480: {
            items: 1
        },
        600: {
            items: 2
        },
        992: {
            items: 3
        },
    }
})

// Product_Section
$('.product-items').owlCarousel({
    loop: false,
    margin: 10,
    nav: true,
    navText: ['<i class="fa fa-angle-left"></i>', '<i class="fa fa-angle-right"></i>'],
    dots: false,
    responsiveClass: true,
    responsive: {
        0: {
            items: 1
        },
        320: {
            items: 2
        },
        576: {
            items: 3
        },
        992: {
            items: 4
        }
    }
});

// Testimonial_Section
$('.testimonial-items').owlCarousel({
    loop: false,
    margin: 10,
    nav: true,
    navText: ['<i class="fa fa-angle-left"></i>', '<i class="fa fa-angle-right"></i>'],
    dots: false,
    responsiveClass: true,
    responsive: {
        0: {
            items: 1
        }
    }
});

// Special_Product
$('.special-items').owlCarousel({
    loop: false,
    margin: 10,
    nav: true,
    navText: ['<i class="fa fa-angle-left"></i>', '<i class="fa fa-angle-right"></i>'],
    dots: false,
    responsiveClass: true,
    responsive: {
        0: {
            items: 1
        },
        320: {
            items: 2
        },
        576: {
            items: 3
        },
        992: {
            items: 4
        }
    }
});

// Blog_Section 
$('.blogs-items').owlCarousel({
    loop: false,
    margin: 30,
    nav: true,
    navText: ['<i class="fa fa-angle-left"></i>', '<i class="fa fa-angle-right"></i>'],
    dots: false,
    responsive: {
        0: {
            items: 1
        },
        1200: {
            items: 2
        }
    }
});

// client_Section 
$('.client').owlCarousel({
    loop: true,
    autoplay: true,
    margin: 10,
    nav: true,
    navText: ['<i class="fa fa-angle-left"></i>', '<i class="fa fa-angle-right"></i>'],
    autoplayTimeout: 2000,
    responsiveRefreshRate: 200,
    dots: false,
    responsive: {
        0: {
            items: 1,
        },
        768: {
            items: 3,
        },
        992: {
            items: 4,
        },
        1200: {
            items: 6,
        }
    }
});


// Footer
$(document).ready(function () {
    $("#contact").click(function () {
        $(".contact").toggleClass("show", 1000);
    });

    $("#information").click(function () {
        $(".information").toggleClass("show", 1000);
    });

    $("#extras").click(function () {
        $(".extras").toggleClass("show", 1000);
    });
});

$(document).ready(function () {
    $("#contact").click(function () {
        $("#contact").toggleClass("arrow-up", 1000);
    });

    $("#information").click(function () {
        $("#information").toggleClass("arrow-up", 1000);
    });

    $("#extras").click(function () {
        $("#extras").toggleClass("arrow-up", 1000);
    });
});



//About Account-Info
$(document).ready(function () {
    $(".account-content").click(function () {
        $("#account-info").toggleClass("show", 1000);
        $(".toggle-open-1").toggleClass("arrow-up", 1000)
    });

    $(".sidebar").click(function () {
        $("#info").toggleClass("show", 1000);
        $(".toggle-open-2").toggleClass("arrow-up", 1000)
    });
});


// Product Page
$('.additional-carousel').owlCarousel({
    loop: true,
    autoplay: false,
    nav: true,
    navText: ['<i class="fa fa-angle-left"></i>', '<i class="fa fa-angle-right"></i>'],
    autoplayTimeout: 2000,
    dots: false,
    responsive: {
        0: {
            items: 1,
        },
        320: {
            items: 2,
        },
        376: {
            items: 3,
        },
        481: {
            items: 4,
        },
        768: {
            items: 3,
        },
        992: {
            items: 4,
        },

    }
});

// Product-Page onclick to show image
jQuery(".additional-carousel a.elevatezoom-gallery").click(function (e) {
    e.preventDefault();
    // var this_img = jQuery(this).find("img");
    // var this_img_src = jQuery(this_img).attr("src");
    var this_img_src = jQuery(this).attr("data-zoom-image");
    jQuery("#prozoom").attr("src", this_img_src);
    // console.log(this_img_src);
    return;
});


// Product-Page onclick to open reviwe section
$(document).ready(function () {
    $(".write-review").on('click', function (event) {
        $('a[href=\'#tab-review\']').tab('show');
        $('body,html').animate({ scrollTop: $('.propage-tab').offset().top - 350 }, 500);
        return false;
    })
})



// Product-Page Add and Minus 
$(document).on('click', '.plus, .minus', function (e) {
    e.preventDefault();
    var parent = $(this).parents('.product-btn-quantity');
    var quantity = parent.find('[name="quantity"]');
    var val = quantity.val();
    if ($(this).hasClass('plus')) {
        val = parseInt(val) + 1;
    } else {
        if (val == 1) {
            val = 1;
        } else {
            val = val >= 1 ? parseInt(val) - 1 : 0;
        }
    }
    quantity.val(val);
    quantity.trigger("change");
    return false;
})


$(document).on('click', '.toggled', function (e) {
    e.preventDefault();
    if (!$(this).parent().hasClass('active')) {
        $('+ ul', $('a.list-group-item.main-item')).slideUp();
        $('a.list-group-item.main-item').removeClass('active');
    }
    $(this).parent().toggleClass('active');
    $('+ ul', $(this).parent()).slideToggle('slow');
    return false;
})

$(document).on('click', '#button-list', function () {
    var element = this;

    $('#product-list').attr('class', 'row row-cols-1 product-list');

    $('#button-grid').removeClass('active');
    $('#button-list').addClass('active');

    localStorage.setItem('display', 'list');
})

$(document).on('click', '#button-grid', function () {
    var element = this;

    // What a shame bootstrap does not take into account dynamically loaded columns
    $('#product-list').attr('class', 'row row-cols-2 row-cols-sm-2 row-cols-md-3 row-cols-lg-3');

    $('#button-list').removeClass('active');
    $('#button-grid').addClass('active');
    localStorage.setItem('display', 'grid');
})




// ...AbortController.apply.apply.apply 
$(document).ready(function() {
    // set column+content
    updateColumnsAndContent();


    $(window).resize(function () {
        // set column+content
        updateColumnsAndContent();
    });

});


  /*----------
    Update column & content in responsive
    -----------*/
    function updateColumnsAndContent() {
        if ($(window).width() < 992) {
            $('#column-left, #column-right').insertAfter('#content');
        }
        else {
            $('#column-right').insertAfter('#content');
            $('#column-left').insertBefore('#content');
        }
    }

    $(".category-content").click(function () {
        $("#select-category").toggleClass("show", 1000);
        $(".toggle-open-1").toggleClass("arrow-up", 1000)
    });

//Contact Us
