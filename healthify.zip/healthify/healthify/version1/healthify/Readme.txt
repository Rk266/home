Credit:
	https://getbootstrap.com

Title:
    Healthify - Healthcare Store HTML5 Website Template
	
Description:
    Healthify Healthcare Store HTML5 Website Template is perfectly designed for drugs, capsules, dressing, pharmacy, surgical, eye ointment, medicines, multipurpose stores. The Stelar Template looking good and professional with its color combination. Built utilizing technologies like Bootstrap 5.0.2, HTML5, CSS3, Jquery and more. Template is all kind of devices (desktop, laptop, tablet, mobile phone) and fully responsive with cross-browser compatibility. 
    
Meta Description:
    Healthify - Healthcare, drugs, capsules, dressing, pharmacy, surgical, eye ointment, medicines, multipurpose stores.

Keyword:
	Healthify, Healthcare, drugs, capsules, dressing, pharmacy , medicines, surgical, eye ointment, shopping, ecommerce, apparel, modern, shopping, responsive
	
	